
def hello(name=""):
    print("Bonjour",name)